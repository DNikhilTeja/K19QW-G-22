from tkinter import *
import backend

index = None
selected_tuple = None


window = Tk()
window.wm_title("Flood Relief Camp")
window.geometry('720x480')

head = Label(window, text = 'Flood Relief Camp',font = ('',25),pady = 5,fg ="#547bb3")
head.grid(row = 0, column = 2)

listing = Listbox(window, height = 6, width = 35)



def get_selected_row(event):
    """Pre-fill fields for selected entry."""
    global selected_tuple
    global index
    index = listing.curselection()[0] 
    selected_tuple = listing.get(index)
    entry1.delete(0, END)
    entry1.insert(END, selected_tuple[1])

    entry2.delete(0, END)
    entry2.insert(END, selected_tuple[2])

    entry3.delete(0, END)
    entry3.insert(END, selected_tuple[3])

    entry4.delete(0, END)
    entry4.insert(END, selected_tuple[4])



def add_command():
    """Insert entry via button."""
    backend.insert(name_text.get(),
                    gender_text.get(),
                    phone_text.get(), 
                    problems_text.get())
    listing.delete(0, END)
    listing.insert(END, 
                    (name_text.get(), 
                    gender_text.get(), 
                    phone_text.get(), 
                    problems_text.get()))

def view_command():
    """View entries via button."""
    listing.delete(0, END)
    for row in backend.view():
        listing.insert(END, row)

def update_command():
    
    """Update entry via button."""
    backend.update(selected_tuple[0], 
                    name_text.get(), 
                    gender_text.get(), 
                    phone_text.get(), 
                    problems_text.get())

def delete_command():
    
    """Delete entry via button."""
    backend.delete(selected_tuple[0])

def search_command():
    """Search entry via button."""
    listing.delete(0, END)
    for row in backend.search(name_text.get(), 
                                gender_text.get(), 
                                phone_text.get(), 
                                problems_text.get()):
        listing.insert(END, row)







# Labels for entry fields.
label1 = Label(window, text = "Name")
label1.grid(row = 2, column = 0)

label2 = Label(window, text = "Gender")
label2.grid(row = 2, column = 2)

label3 = Label(window, text = "Phone no")
label3.grid(row = 3, column = 0)

label4 = Label(window, text = "Problems")
label4.grid(row = 3, column = 2)

# Entry Fields.
name_text = StringVar()
entry1 = Entry(window, textvariable = name_text)
entry1.grid(row = 2, column = 1)

gender_text = StringVar()
entry2 = Entry(window, textvariable = gender_text)
entry2.grid(row = 2, column = 3)

phone_text = StringVar()
entry3 = Entry(window, textvariable = phone_text)
entry3.grid(row = 3, column = 1)

problems_text = StringVar()
entry4 = Entry(window, textvariable = problems_text)
entry4.grid(row = 3, column = 3)

# List all data.

listing.grid(row = 4, column = 0, rowspan = 6, columnspan = 2)

# Scrollbar.
scroller = Scrollbar(window)
scroller.grid(row = 4, column = 2, rowspan = 6)

# Configure scrollbar for Listbox.
listing.configure(yscrollcommand = scroller.set)
scroller.configure(command = listing.yview)

listing.bind('<<ListboxSelect>>', get_selected_row)

# Buttons for various operations on data.
button1 = Button(window, 
                text = "View All", 
                width = 12, 
                command = view_command)
button1.grid(row = 4, column = 3)

button2 = Button(window, 
                text = "Search Entry", 
                width = 12, 
                command = search_command)
button2.grid(row = 5, column = 3)

button3 = Button(window, 
                text = "Add Entry", 
                width = 12, 
                command = add_command)
button3.grid(row = 6, column = 3)

button4 = Button(window, 
                text = "Update Selected", 
                width = 12, 
                command = update_command)
button4.grid(row = 7, column = 3)

button5 = Button(window, 
                text = "Delete Selected", 
                width = 12, 
                command = delete_command)
button5.grid(row = 8, column = 3)

button6 = Button(window, 
                text = "Close", 
                width = 12, 
                command = window.destroy)
button6.grid(row = 9, column = 3)

# Keep window open until closed.
window.mainloop()
