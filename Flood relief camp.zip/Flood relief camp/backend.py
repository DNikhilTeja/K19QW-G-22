import sqlite3

def connect():
    """Set up a connection with the database."""
    conn_obj = sqlite3.connect("flood.db")
    cur_obj = conn_obj.cursor()
    cur_obj.execute("CREATE TABLE IF NOT EXISTS "
                    "flood (id integer PRIMARY KEY, "
                            "name text, "
                            "gender text, "
                            "phone integer, "
                            "problems integer)")
    conn_obj.commit()
    conn_obj.close()

def insert(name, gender, phone, problems):
    """Insert entry into database."""
    conn_obj = sqlite3.connect("flood.db")
    cur_obj = conn_obj.cursor()
    cur_obj.execute("INSERT INTO flood "
                    "VALUES (NULL, ?, ?, ?, ?)", (name, gender, phone, problems))
    conn_obj.commit()
    conn_obj.close()

def view():
    """View all database entries."""
    conn_obj = sqlite3.connect("flood.db")
    cur_obj = conn_obj.cursor()
    cur_obj.execute("SELECT * FROM flood")
    rows = cur_obj.fetchall()
    conn_obj.close()
    return rows

def update(id, name, gender, phone, problems):
    """Update a database entry."""
    conn_obj = sqlite3.connect("flood.db")
    cur_obj = conn_obj.cursor()
    cur_obj.execute("UPDATE flood "
                    "SET name = ?, "
                    "gender = ?, "
                    "phone = ?, "
                    "problems = ? "
                    "WHERE id = ?", 
                    (name, gender, phone, problems, id))
    conn_obj.commit()
    conn_obj.close()

def delete(id):
    """Delete a database entry."""
    conn_obj = sqlite3.connect("flood.db")
    cur_obj = conn_obj.cursor()
    cur_obj.execute("DELETE FROM flood "
                    "WHERE id = ?", (id,))
    conn_obj.commit()
    conn_obj.close()

def search(name = "", gender = "", phone = "", problems = ""):
    """Search for a database entry."""
    conn_obj = sqlite3.connect("flood.db")
    cur_obj = conn_obj.cursor()
    cur_obj.execute("SELECT * "
                    "FROM flood "
                    "WHERE name = ? OR gender = ? OR phone = ? OR problems = ?", 
                    (name, gender, phone, problems))
    rows = cur_obj.fetchall()
    conn_obj.close()
    return rows
    
connect()
